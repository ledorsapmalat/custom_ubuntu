/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("graphics-canvas-default",function(a){a.Graphic=a.CanvasGraphic;a.Shape=a.CanvasShape;a.Circle=a.CanvasCircle;a.Rect=a.CanvasRect;a.Ellipse=a.CanvasEllipse;a.Path=a.CanvasPath;a.Drawing=a.CanvasDrawing;},"3.5.1",{skinnable:false});