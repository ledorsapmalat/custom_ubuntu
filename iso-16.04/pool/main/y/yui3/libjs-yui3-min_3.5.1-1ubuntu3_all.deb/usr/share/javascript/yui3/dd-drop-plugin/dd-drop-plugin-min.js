/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("dd-drop-plugin",function(a){var b=function(c){c.node=c.host;b.superclass.constructor.apply(this,arguments);};b.NAME="dd-drop-plugin";b.NS="drop";a.extend(b,a.DD.Drop);a.namespace("Plugin");a.Plugin.Drop=b;},"3.5.1",{skinnable:false,requires:["dd-drop"]});