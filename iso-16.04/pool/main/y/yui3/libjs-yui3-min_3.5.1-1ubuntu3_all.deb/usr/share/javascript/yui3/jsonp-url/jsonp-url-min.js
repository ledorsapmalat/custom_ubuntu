/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("jsonp-url",function(d){var a=d.JSONPRequest,c=d.Object.getValue,b=function(){};d.mix(a.prototype,{_pattern:/\bcallback=(.*?)(?=&|$)/i,_template:"callback={callback}",_defaultCallback:function(g){var f=g.match(this._pattern),j=[],h=0,e,k,l;if(f){e=f[1].replace(/\[(['"])(.*?)\1\]/g,function(m,i,n){j[h]=n;return".@"+(h++);}).replace(/\[(\d+)\]/g,function(m,i){j[h]=parseInt(i,10)|0;return".@"+(h++);}).replace(/^\./,"");if(!/[^\w\.\$@]/.test(e)){k=e.split(".");for(h=k.length-1;h>=0;--h){if(k[h].charAt(0)==="@"){k[h]=j[parseInt(k[h].substr(1),10)];}}l=c(d.config.win,k)||c(d,k)||c(d,k.slice(1));}}return l||b;},_format:function(e,g){var h=this._template.replace(/\{callback\}/,g),f;if(this._pattern.test(e)){return e.replace(this._pattern,h);}else{f=e.slice(-1);if(f!=="&"&&f!=="?"){e+=(e.indexOf("?")>-1)?"&":"?";}return e+h;}}},true);},"3.5.1",{requires:["jsonp"]});