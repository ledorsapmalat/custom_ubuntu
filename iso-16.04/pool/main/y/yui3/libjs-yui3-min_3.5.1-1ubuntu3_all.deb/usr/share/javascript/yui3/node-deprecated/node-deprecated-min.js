/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("node-deprecated",function(b){var a=b.Node;a.ATTRS.data={getter:function(){return this._dataVal;},setter:function(c){this._dataVal=c;return c;},value:null};b.get=a.get=function(){return a.one.apply(a,arguments);};b.mix(a.prototype,{query:function(c){return this.one(c);},queryAll:function(c){return this.all(c);},each:function(d,c){c=c||this;return d.call(c,this);},item:function(c){return this;},size:function(){return this._node?1:0;}});},"3.5.1",{requires:["node-base"]});