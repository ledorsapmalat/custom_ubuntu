/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("dd-gestures",function(a){a.DD.Drag.START_EVENT="gesturemovestart";a.DD.Drag.prototype._prep=function(){this._dragThreshMet=false;var c=this.get("node"),b=a.DD.DDM;c.addClass(b.CSS_PREFIX+"-draggable");c.on(a.DD.Drag.START_EVENT,a.bind(this._handleMouseDownEvent,this),{minDistance:0,minTime:0});c.on("gesturemoveend",a.bind(this._handleMouseUp,this),{standAlone:true});c.on("dragstart",a.bind(this._fixDragStart,this));};a.DD.DDM._setupListeners=function(){var b=a.DD.DDM;this._createPG();this._active=true;a.one(a.config.doc).on("gesturemove",a.throttle(a.bind(b._move,b),b.get("throttleTime")),{standAlone:true});};},"3.5.1",{skinnable:false,requires:["dd-drag","event-synthetic","event-gestures"]});