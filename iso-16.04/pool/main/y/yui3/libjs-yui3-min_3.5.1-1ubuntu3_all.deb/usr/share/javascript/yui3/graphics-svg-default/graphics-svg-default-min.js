/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("graphics-svg-default",function(a){a.Graphic=a.SVGGraphic;a.Shape=a.SVGShape;a.Circle=a.SVGCircle;a.Rect=a.SVGRect;a.Ellipse=a.SVGEllipse;a.Path=a.SVGPath;a.Drawing=a.SVGDrawing;},"3.5.1",{skinnable:false});