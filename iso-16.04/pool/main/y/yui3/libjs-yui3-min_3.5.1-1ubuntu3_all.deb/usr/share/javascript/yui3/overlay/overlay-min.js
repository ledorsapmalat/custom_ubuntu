/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("overlay",function(a){a.Overlay=a.Base.create("overlay",a.Widget,[a.WidgetStdMod,a.WidgetPosition,a.WidgetStack,a.WidgetPositionAlign,a.WidgetPositionConstrain]);},"3.5.1",{requires:["widget","widget-stdmod","widget-position","widget-stack","widget-position-align","widget-position-constrain"]});