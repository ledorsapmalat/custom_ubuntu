/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("tabview-plugin",function(b){function a(){a.superclass.constructor.apply(this,arguments);}a.NAME="tabviewPlugin";a.NS="tabs";b.extend(a,b.TabviewBase);b.namespace("Plugin");b.Plugin.Tabview=a;},"3.5.1",{requires:["tabview-base"]});