/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("io-form",function(b){var a=encodeURIComponent;b.mix(b.IO.prototype,{_serialize:function(w,B){var q=[],y=w.useDisabled||false,A=0,g=(typeof w.id==="string")?w.id:w.id.getAttribute("id"),t,r,k,z,u,p,x,l,m,h;if(!g){g=b.guid("io:");w.id.setAttribute("id",g);}r=b.config.doc.getElementById(g);for(p=0,x=r.elements.length;p<x;++p){t=r.elements[p];u=t.disabled;k=t.name;if(y?k:k&&!u){k=a(k)+"=";z=a(t.value);switch(t.type){case"select-one":if(t.selectedIndex>-1){h=t.options[t.selectedIndex];q[A++]=k+a(h.attributes.value&&h.attributes.value.specified?h.value:h.text);}break;case"select-multiple":if(t.selectedIndex>-1){for(l=t.selectedIndex,m=t.options.length;l<m;++l){h=t.options[l];if(h.selected){q[A++]=k+a(h.attributes.value&&h.attributes.value.specified?h.value:h.text);}}}break;case"radio":case"checkbox":if(t.checked){q[A++]=k+z;}break;case"file":case undefined:case"reset":case"button":break;case"submit":default:q[A++]=k+z;}}}return B?q.join("&")+"&"+B:q.join("&");}},true);},"3.5.1",{requires:["io-base","node-base"]});