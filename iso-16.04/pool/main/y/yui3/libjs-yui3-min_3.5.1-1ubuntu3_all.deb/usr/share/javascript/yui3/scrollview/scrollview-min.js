/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("scrollview",function(a){a.Base.plug(a.ScrollView,a.Plugin.ScrollViewScrollbars);},"3.5.1",{requires:["scrollview-base","scrollview-scrollbars"]});