/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("graphics-vml-default",function(a){a.Graphic=a.VMLGraphic;a.Shape=a.VMLShape;a.Circle=a.VMLCircle;a.Rect=a.VMLRect;a.Ellipse=a.VMLEllipse;a.Path=a.VMLPath;a.Drawing=a.VMLDrawing;},"3.5.1",{skinnable:false});