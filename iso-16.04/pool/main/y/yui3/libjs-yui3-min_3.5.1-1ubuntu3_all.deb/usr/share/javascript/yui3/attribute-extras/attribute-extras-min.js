/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("attribute-extras",function(f){var a="broadcast",d="published",e="initValue",c={readOnly:1,writeOnce:1,getter:1,broadcast:1};function b(){}b.prototype={modifyAttr:function(h,g){var i=this,k,j;if(i.attrAdded(h)){if(i._isLazyAttr(h)){i._addLazyAttr(h);}j=i._state;for(k in g){if(c[k]&&g.hasOwnProperty(k)){j.add(h,k,g[k]);if(k===a){j.remove(h,d);}}}}},removeAttr:function(g){this._state.removeAll(g);},reset:function(g){var h=this;if(g){if(h._isLazyAttr(g)){h._addLazyAttr(g);}h.set(g,h._state.get(g,e));}else{f.each(h._state.data,function(i,j){h.reset(j);});}return h;},_getAttrCfg:function(g){var i,h=this._state;if(g){i=h.getAll(g)||{};}else{i={};f.each(h.data,function(j,k){i[k]=h.getAll(k);});}return i;}};f.AttributeExtras=b;},"3.5.1");