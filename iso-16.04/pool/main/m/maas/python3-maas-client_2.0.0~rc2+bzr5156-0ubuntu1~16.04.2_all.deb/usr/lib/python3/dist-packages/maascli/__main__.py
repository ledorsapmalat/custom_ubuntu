#!/usr/bin/env python3.5
# Copyright 2012-2015 Canonical Ltd.  This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""Command-line interface for MAAS."""

from . import main


main()
