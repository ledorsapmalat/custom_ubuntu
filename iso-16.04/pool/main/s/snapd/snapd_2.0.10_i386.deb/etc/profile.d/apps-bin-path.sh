# Expand the $PATH to include /snap/bin which is what snappy applications
# use
PATH=$PATH:/snap/bin
