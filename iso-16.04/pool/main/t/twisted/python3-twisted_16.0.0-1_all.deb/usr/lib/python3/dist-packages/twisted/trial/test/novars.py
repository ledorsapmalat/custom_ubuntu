# fodder for test_script, which parses files for emacs local variable
# declarations.  This one is supposed to have none.
# The class declaration is irrelevant

class Bar(object):
    pass
