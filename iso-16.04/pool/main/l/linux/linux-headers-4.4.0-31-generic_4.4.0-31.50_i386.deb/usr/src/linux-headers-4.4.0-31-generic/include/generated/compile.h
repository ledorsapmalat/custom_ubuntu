/* This file is auto generated, version 50-Ubuntu */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#50-Ubuntu SMP Wed Jul 13 00:06:14 UTC 2016"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-58"
#define LINUX_COMPILER "gcc version 5.3.1 20160413 (Ubuntu 5.3.1-14ubuntu2.1) "
