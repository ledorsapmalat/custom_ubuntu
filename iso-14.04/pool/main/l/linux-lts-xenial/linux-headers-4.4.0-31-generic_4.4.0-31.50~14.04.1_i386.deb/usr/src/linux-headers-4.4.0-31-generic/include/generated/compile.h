/* This file is auto generated, version 50~14.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#50~14.04.1-Ubuntu SMP Wed Jul 13 01:06:37 UTC 2016"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-01"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04.3) "
