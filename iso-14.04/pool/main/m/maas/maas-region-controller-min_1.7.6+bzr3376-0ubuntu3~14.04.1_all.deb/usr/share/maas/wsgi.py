# Copyright 2012 Canonical Ltd.  This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""WSGI Application."""

from __future__ import (
    absolute_import,
    print_function,
    unicode_literals,
    )

str = None

__metaclass__ = type
__all__ = [
    'application',
    ]

import os
import sys


current_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_path)

os.environ['DJANGO_SETTINGS_MODULE'] = 'maas.settings'

# Use Django 1.6 if the python-django16 package is installed: this is
# to get MAAS to work on vivid: vivid ships with Django 1.7 by default
# and MAAS isn't yet compatible with Django 1.7.
if os.path.exists('/usr/lib/django16'):
    sys.path.insert(1, '/usr/lib/django16')

import django.core.handlers.wsgi
application = django.core.handlers.wsgi.WSGIHandler()


from maasserver.start_up import start_up
start_up()
