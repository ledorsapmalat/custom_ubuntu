#!/usr/bin/python

'''apport hook for maas-region-controller

(c) 2012 Canonical Ltd.
Author: Andres Rodriguez <andres.rodriguez@canonical.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.  See http://www.gnu.org/copyleft/gpl.html for
the full text of the license.
'''

from apport.hookutils import *

def add_info(report, ui):
    response = ui.yesno("The contents of your /etc/maas/maas_local_settings.py, "
                        "/etc/maas/pserv.yaml files "
                        "may help developers diagnose your bug more "
                        "quickly.  However, it may contain sensitive "
                        "information.  Do you want to include it in your "
                        "bug report?")

    if response == None: # user cancelled
        raise StopIteration

    elif response == True:
        attach_conffiles(report,'maas')

    # Attaching log files
    attach_file_if_exists(report, '/var/log/maas/maas-django.log', 'MAASLog')
    attach_file_if_exists(report, '/var/log/maas/pserv.log', 'MAASPservLog')

    # Attaching related packages info
    attach_related_packages(report, ['python-django-maas', 'apparmor'])
