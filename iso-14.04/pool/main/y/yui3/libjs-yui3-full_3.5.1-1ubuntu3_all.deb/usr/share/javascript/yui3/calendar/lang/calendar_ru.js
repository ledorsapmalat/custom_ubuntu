/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar_ru",function(a){a.Intl.add("calendar","ru",{weekdays:["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],very_short_weekdays:["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],first_weekday:1,weekends:[0,6]});},"3.5.1");