/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar_pt-BR",function(a){a.Intl.add("calendar","pt-BR",{weekdays:["Domingo","Segunda","Ter\u00E7a","Quarta","Quinta","Sexta","S\u00E1bado"],short_weekdays:["Dom","Seg","Ter","Qua","Qui","Sex","Sab"],very_short_weekdays:["Dom","Seg","Ter","Qua","Qui","Sex","Sab"]});},"3.5.1");