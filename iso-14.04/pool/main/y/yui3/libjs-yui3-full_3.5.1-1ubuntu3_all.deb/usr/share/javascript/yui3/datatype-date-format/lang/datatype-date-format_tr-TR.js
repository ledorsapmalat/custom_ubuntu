/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_tr-TR",function(a){a.Intl.add("datatype-date-format","tr-TR",{"a":["Paz","Pzt","Sal","Çar","Per","Cum","Cmt"],"A":["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"],"b":["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"],"B":["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],"c":"%d %b %Y %a %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d.%m.%Y","X":"%H:%M:%S"});},"3.5.1");