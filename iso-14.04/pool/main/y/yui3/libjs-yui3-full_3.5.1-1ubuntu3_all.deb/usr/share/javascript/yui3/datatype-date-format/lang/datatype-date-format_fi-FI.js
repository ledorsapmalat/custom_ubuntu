/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_fi-FI",function(a){a.Intl.add("datatype-date-format","fi-FI",{"a":["su","ma","ti","ke","to","pe","la"],"A":["sunnuntaina","maanantaina","tiistaina","keskiviikkona","torstaina","perjantaina","lauantaina"],"b":["tammikuuta","helmikuuta","maaliskuuta","huhtikuuta","toukokuuta","kesäkuuta","heinäkuuta","elokuuta","syyskuuta","lokakuuta","marraskuuta","joulukuuta"],"B":["tammikuuta","helmikuuta","maaliskuuta","huhtikuuta","toukokuuta","kesäkuuta","heinäkuuta","elokuuta","syyskuuta","lokakuuta","marraskuuta","joulukuuta"],"c":"%a %d. %b %Y %k.%M.%S %Z","p":["AP.","IP."],"P":["ap.","ip."],"x":"%d.%m.%Y","X":"%k.%M.%S"});},"3.5.1");