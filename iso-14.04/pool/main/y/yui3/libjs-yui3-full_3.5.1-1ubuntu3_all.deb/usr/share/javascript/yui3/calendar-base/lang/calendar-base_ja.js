/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar-base_ja",function(a){a.Intl.add("calendar-base","ja",{weekdays:["\u65E5\u66DC\u65E5","\u6708\u66DC\u65E5","\u706B\u66DC\u65E5","\u6C34\u66DC\u65E5","\u6728\u66DC\u65E5","\u91D1\u66DC\u65E5","\u571F\u66DC\u65E5"],short_weekdays:["\u65E5\u66DC","\u6708\u66DC","\u706B\u66DC","\u6C34\u66DC","\u6728\u66DC","\u91D1\u66DC","\u571F\u66DC"],very_short_weekdays:["\u65E5","\u6708","\u706B","\u6C34","\u6728","\u91D1","\u571F"],first_weekday:0,weekends:[0,6]});},"3.5.1");