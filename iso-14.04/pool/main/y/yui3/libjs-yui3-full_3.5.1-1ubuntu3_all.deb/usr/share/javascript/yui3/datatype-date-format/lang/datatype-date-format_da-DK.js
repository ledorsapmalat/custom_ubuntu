/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_da-DK",function(a){a.Intl.add("datatype-date-format","da-DK",{"a":["søn","man","tir","ons","tor","fre","lør"],"A":["søndag","mandag","tirsdag","onsdag","torsdag","fredag","lørdag"],"b":["jan.","feb.","mar.","apr.","maj","jun.","jul.","aug.","sep.","okt.","nov.","dec."],"B":["januar","februar","marts","april","maj","juni","juli","august","september","oktober","november","december"],"c":"%a. %d. %b %Y %H.%M.%S %Z","p":["F.M.","E.M."],"P":["f.m.","e.m."],"x":"%d/%m/%y","X":"%H.%M.%S"});},"3.5.1");