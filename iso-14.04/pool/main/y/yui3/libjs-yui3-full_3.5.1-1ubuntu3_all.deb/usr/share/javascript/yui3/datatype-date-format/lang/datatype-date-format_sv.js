/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_sv",function(a){a.Intl.add("datatype-date-format","sv",{"a":["sön","mån","tis","ons","tors","fre","lör"],"A":["söndag","måndag","tisdag","onsdag","torsdag","fredag","lördag"],"b":["jan","feb","mar","apr","maj","jun","jul","aug","sep","okt","nov","dec"],"B":["januari","februari","mars","april","maj","juni","juli","augusti","september","oktober","november","december"],"c":"%a %d %b %Y kl. %H.%M.%S %Z","p":["FM","EM"],"P":["fm","em"],"x":"%Y-%m-%d","X":"kl. %H.%M.%S"});},"3.5.1");