/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar",function(a){a.Intl.add("calendar","",{weekdays:["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],short_weekdays:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],very_short_weekdays:["Mo","Tu","We","Th","Fr","Sa","Su"]});},"3.5.1");