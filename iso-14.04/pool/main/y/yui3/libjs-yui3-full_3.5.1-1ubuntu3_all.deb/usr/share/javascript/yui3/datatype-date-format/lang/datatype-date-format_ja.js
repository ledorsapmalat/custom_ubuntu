/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_ja",function(a){a.Intl.add("datatype-date-format","ja",{"a":["\u65E5","\u6708","\u706B","\u6C34","\u6728","\u91D1","\u571F"],"A":["\u65E5\u66DC\u65E5","\u6708\u66DC\u65E5","\u706B\u66DC\u65E5","\u6C34\u66DC\u65E5","\u6728\u66DC\u65E5","\u91D1\u66DC\u65E5","\u571F\u66DC\u65E5"],"b":["1\u6708","2\u6708","3\u6708","4\u6708","5\u6708","6\u6708","7\u6708","8\u6708","9\u6708","10\u6708","11\u6708","12\u6708"],"B":["1\u6708","2\u6708","3\u6708","4\u6708","5\u6708","6\u6708","7\u6708","8\u6708","9\u6708","10\u6708","11\u6708","12\u6708"],"c":"%Y\u5E74%m\u6708%d\u65E5(%a)%k\u6642%M\u5206%S\u79D2 %Z","p":["\u5348\u524D","\u5348\u5F8C"],"P":["\u5348\u524D","\u5348\u5F8C"],"x":"%y/%m/%d","X":"%k\u6642%M\u5206%S\u79D2"});},"3.5.1");