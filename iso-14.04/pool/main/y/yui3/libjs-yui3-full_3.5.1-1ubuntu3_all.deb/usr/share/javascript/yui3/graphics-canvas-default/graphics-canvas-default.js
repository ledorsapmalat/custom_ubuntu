/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add('graphics-canvas-default', function(Y) {

Y.Graphic = Y.CanvasGraphic;
Y.Shape = Y.CanvasShape;
Y.Circle = Y.CanvasCircle;
Y.Rect = Y.CanvasRect;
Y.Ellipse = Y.CanvasEllipse;
Y.Path = Y.CanvasPath;
Y.Drawing = Y.CanvasDrawing;


}, '3.5.1' ,{skinnable:false});
