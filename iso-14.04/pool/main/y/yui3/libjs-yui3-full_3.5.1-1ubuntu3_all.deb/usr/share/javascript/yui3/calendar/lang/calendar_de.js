/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar_de",function(a){a.Intl.add("calendar","de",{weekdays:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],very_short_weekdays:["So","Mo","Di","Mi","Do","Fr","Sa"],first_weekday:1,weekends:[0,6]});},"3.5.1");