/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_ru-RU",function(a){a.Intl.add("datatype-date-format","ru-RU",{"a":["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],"A":["воскресенье","понедельник","вторник","среда","четверг","пятница","суббота"],"b":["янв.","февр.","марта","апр.","мая","июня","июля","авг.","сент.","окт.","нояб.","дек."],"B":["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"],"c":"%a, %d %b %Y %k:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d.%m.%y","X":"%k:%M:%S"});},"3.5.1");