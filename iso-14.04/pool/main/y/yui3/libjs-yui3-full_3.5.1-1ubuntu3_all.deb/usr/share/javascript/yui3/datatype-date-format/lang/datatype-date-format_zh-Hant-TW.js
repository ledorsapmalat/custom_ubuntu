/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_zh-Hant-TW",function(a){a.Intl.add("datatype-date-format","zh-Hant-TW",{"a":["週日","週一","週二","週三","週四","週五","週六"],"A":["星期日","星期一","星期二","星期三","星期四","星期五","星期六"],"b":["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],"B":["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],"c":"%Y年%b%d日%a%Z%p%l時%M分%S秒","p":["上午","下午"],"P":["上午","下午"],"x":"%y/%m/%d","X":"%p%l時%M分%S秒"});},"3.5.1");