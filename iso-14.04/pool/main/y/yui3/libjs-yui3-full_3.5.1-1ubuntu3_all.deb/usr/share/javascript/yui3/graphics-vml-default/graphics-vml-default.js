/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add('graphics-vml-default', function(Y) {

Y.Graphic = Y.VMLGraphic;
Y.Shape = Y.VMLShape;
Y.Circle = Y.VMLCircle;
Y.Rect = Y.VMLRect;
Y.Ellipse = Y.VMLEllipse;
Y.Path = Y.VMLPath;
Y.Drawing = Y.VMLDrawing;


}, '3.5.1' ,{skinnable:false});
