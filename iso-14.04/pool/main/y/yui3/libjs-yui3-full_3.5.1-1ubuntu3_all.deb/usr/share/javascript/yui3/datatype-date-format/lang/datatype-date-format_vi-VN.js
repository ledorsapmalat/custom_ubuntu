/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_vi-VN",function(a){a.Intl.add("datatype-date-format","vi-VN",{"a":["CN","Th 2","Th 3","Th 4","Th 5","Th 6","Th 7"],"A":["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"],"b":["thg 1","thg 2","thg 3","thg 4","thg 5","thg 6","thg 7","thg 8","thg 9","thg 10","thg 11","thg 12"],"B":["tháng một","tháng hai","tháng ba","tháng tư","tháng năm","tháng sáu","tháng bảy","tháng tám","tháng chín","tháng mười","tháng mười một","tháng mười hai"],"c":"%H:%M:%S %Z %a, %d %b %Y","p":["SA","CH"],"P":["sa","ch"],"x":"%d/%m/%Y","X":"%H:%M:%S"});},"3.5.1");