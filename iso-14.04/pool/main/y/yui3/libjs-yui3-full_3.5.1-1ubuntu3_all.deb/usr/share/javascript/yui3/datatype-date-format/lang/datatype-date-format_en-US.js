/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_en-US",function(a){a.Intl.add("datatype-date-format","en-US",{"a":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"A":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"b":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"B":["January","February","March","April","May","June","July","August","September","October","November","December"],"c":"%a, %b %d, %Y %l:%M:%S %p %Z","p":["AM","PM"],"P":["am","pm"],"x":"%m/%d/%y","X":"%l:%M:%S %p"});},"3.5.1");