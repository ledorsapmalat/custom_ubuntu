/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar_ja",function(a){a.Intl.add("calendar","ja",{weekdays:["\u6708\u66DC\u65E5","\u706B\u66DC\u65E5","\u6C34\u66DC\u65E5","\u6728\u66DC\u65E5","\u91D1\u66DC\u65E5","\u571F\u66DC\u65E5","\u65E5\u66DC\u65E5"],short_weekdays:["\u6708\u66DC","\u706B\u66DC","\u6C34\u66DC","\u6728\u66DC","\u91D1\u66DC","\u571F\u66DC","\u65E5\u66DC"],very_short_weekdays:["\u6708","\u706B","\u6C34","\u6728","\u91D1","\u571F","\u65E5"]});},"3.5.1");