/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_ms-MY",function(a){a.Intl.add("datatype-date-format","ms-MY",{"a":["Ahd","Isn","Sel","Rab","Kha","Jum","Sab"],"A":["Ahad","Isnin","Selasa","Rabu","Khamis","Jumaat","Sabtu"],"b":["Jan","Feb","Mac","Apr","Mei","Jun","Jul","Ogos","Sep","Okt","Nov","Dis"],"B":["Januari","Februari","Mac","April","Mei","Jun","Julai","Ogos","September","Oktober","November","Disember"],"c":"%a, %Y %b %d %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%Y-%m-%d","X":"%H:%M:%S"});},"3.5.1");