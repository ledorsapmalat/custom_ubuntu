/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/console_es",function(a){a.Intl.add("console","es",{title:"Consola de informacion",pause:"Pausa",clear:"Borrar",collapse:"Colapsar",expand:"Expandir"});},"3.5.1");