/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_fr-CA",function(a){a.Intl.add("datatype-date-format","fr-CA",{"a":["dim.","lun.","mar.","mer.","jeu.","ven.","sam."],"A":["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"],"b":["janv.","févr.","mars","avr.","mai","juin","juil.","août","sept.","oct.","nov.","déc."],"B":["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre"],"c":"%a %d %b %Y %H h %M min %S s %Z","p":["AM","PM"],"P":["am","pm"],"x":"%y-%m-%d","X":"%H h %M min %S s"});},"3.5.1");