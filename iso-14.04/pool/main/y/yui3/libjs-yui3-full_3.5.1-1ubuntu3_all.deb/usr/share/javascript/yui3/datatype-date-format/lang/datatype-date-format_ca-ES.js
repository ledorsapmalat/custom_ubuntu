/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_ca-ES",function(a){a.Intl.add("datatype-date-format","ca-ES",{"a":["dg.","dl.","dt.","dc.","dj.","dv.","ds."],"A":["diumenge","dilluns","dimarts","dimecres","dijous","divendres","dissabte"],"b":["gen.","febr.","març","abr.","maig","juny","jul.","ag.","set.","oct.","nov.","des."],"B":["gener","febrer","març","abril","maig","juny","juliol","agost","setembre","octubre","novembre","desembre"],"c":"%a %d %b %Y %k:%M:%S %Z","p":["A.M.","P.M."],"P":["a.m.","p.m."],"x":"%d/%m/%y","X":"%k:%M:%S"});},"3.5.1");