/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_en-GB",function(a){a.Intl.add("datatype-date-format","en-GB",{"a":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"A":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"b":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"B":["January","February","March","April","May","June","July","August","September","October","November","December"],"c":"%a, %b %d, %Y %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d/%m/%Y","X":"%H:%M:%S"});},"3.5.1");