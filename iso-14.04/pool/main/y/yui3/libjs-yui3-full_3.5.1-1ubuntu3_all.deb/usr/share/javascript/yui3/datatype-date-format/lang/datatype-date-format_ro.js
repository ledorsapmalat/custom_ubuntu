/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_ro",function(a){a.Intl.add("datatype-date-format","ro",{"a":["Du","Lu","Ma","Mi","Jo","Vi","Sâ"],"A":["duminică","luni","marți","miercuri","joi","vineri","sâmbătă"],"b":["ian.","feb.","mar.","apr.","mai","iun.","iul.","aug.","sept.","oct.","nov.","dec."],"B":["ianuarie","februarie","martie","aprilie","mai","iunie","iulie","august","septembrie","octombrie","noiembrie","decembrie"],"c":"%a, %d %b %Y, %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d.%m.%Y","X":"%H:%M:%S"});},"3.5.1");