/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_nl-BE",function(a){a.Intl.add("datatype-date-format","nl-BE",{"a":["zo","ma","di","wo","do","vr","za"],"A":["zondag","maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"],"b":["jan.","feb.","mrt.","apr.","mei","jun.","jul.","aug.","sep.","okt.","nov.","dec."],"B":["januari","februari","maart","april","mei","juni","juli","augustus","september","oktober","november","december"],"c":"%a %d %b %Y %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d/%m/%y","X":"%H:%M:%S"});},"3.5.1");