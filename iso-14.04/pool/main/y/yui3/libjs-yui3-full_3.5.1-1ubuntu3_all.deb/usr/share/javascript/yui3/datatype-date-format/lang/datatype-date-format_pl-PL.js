/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_pl-PL",function(a){a.Intl.add("datatype-date-format","pl-PL",{"a":["niedz.","pon.","wt.","śr.","czw.","pt.","sob."],"A":["niedziela","poniedziałek","wtorek","środa","czwartek","piątek","sobota"],"b":["sty","lut","mar","kwi","maj","cze","lip","sie","wrz","paź","lis","gru"],"B":["stycznia","lutego","marca","kwietnia","maja","czerwca","lipca","sierpnia","września","października","listopada","grudnia"],"c":"%a, %d %b %Y %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d-%m-%y","X":"%H:%M:%S"});},"3.5.1");