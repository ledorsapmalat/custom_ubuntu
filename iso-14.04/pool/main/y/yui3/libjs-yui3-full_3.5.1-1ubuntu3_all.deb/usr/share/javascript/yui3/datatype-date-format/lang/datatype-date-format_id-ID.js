/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_id-ID",function(a){a.Intl.add("datatype-date-format","id-ID",{"a":["Min","Sen","Sel","Rab","Kam","Jum","Sab"],"A":["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"],"b":["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"],"B":["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],"c":"%a, %Y %b %d %H:%M:%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d/%m/%y","X":"%H:%M:%S"});},"3.5.1");