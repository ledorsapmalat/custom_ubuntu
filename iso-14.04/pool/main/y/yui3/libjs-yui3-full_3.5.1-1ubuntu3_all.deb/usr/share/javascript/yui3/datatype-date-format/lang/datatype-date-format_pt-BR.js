/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_pt-BR",function(a){a.Intl.add("datatype-date-format","pt-BR",{"a":["dom","seg","ter","qua","qui","sex","sáb"],"A":["domingo","segunda-feira","terça-feira","quarta-feira","quinta-feira","sexta-feira","sábado"],"b":["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"],"B":["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"],"c":"%a, %d de %b de %Y %Hh%Mmin%Ss %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d/%m/%y","X":"%Hh%Mmin%Ss"});},"3.5.1");