/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar-base",function(a){a.Intl.add("calendar-base","",{weekdays:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],short_weekdays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],very_short_weekdays:["Su","Mo","Tu","We","Th","Fr","Sa"],first_weekday:0,weekends:[0,6]});},"3.5.1");