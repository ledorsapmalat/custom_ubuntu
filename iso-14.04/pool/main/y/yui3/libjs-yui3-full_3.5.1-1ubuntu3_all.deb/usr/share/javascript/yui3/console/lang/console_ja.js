/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/console_ja",function(a){a.Intl.add("console","ja",{title:"\u30ED\u30B0\u30B3\u30F3\u30BD\u30FC\u30EB",pause:"\u4E00\u6642\u505C\u6B62",clear:"\u30AF\u30EA\u30A2",collapse:"\u9589\u3058\u308B",expand:"\u958B\u304F"});},"3.5.1");