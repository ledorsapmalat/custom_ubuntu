/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/dial",function(a){a.Intl.add("dial","",{label:"My label",resetStr:"Reset",tooltipHandle:"Drag to set value"});},"3.5.1");