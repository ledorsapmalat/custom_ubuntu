/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_de-DE",function(a){a.Intl.add("datatype-date-format","de-DE",{"a":["So.","Mo.","Di.","Mi.","Do.","Fr.","Sa."],"A":["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],"b":["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"],"B":["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"],"c":"%a, %d. %b %Y %H:%M:%S %Z","p":["VORM.","NACHM."],"P":["vorm.","nachm."],"x":"%d.%m.%y","X":"%H:%M:%S"});},"3.5.1");