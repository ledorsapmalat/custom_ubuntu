/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_it-IT",function(a){a.Intl.add("datatype-date-format","it-IT",{"a":["dom","lun","mar","mer","gio","ven","sab"],"A":["domenica","lunedì","martedì","mercoledì","giovedì","venerdì","sabato"],"b":["gen","feb","mar","apr","mag","giu","lug","ago","set","ott","nov","dic"],"B":["gennaio","febbraio","marzo","aprile","maggio","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre"],"c":"%a %d %b %Y %H.%M.%S %Z","p":["M.","P."],"P":["m.","p."],"x":"%d/%m/%y","X":"%H.%M.%S"});},"3.5.1");