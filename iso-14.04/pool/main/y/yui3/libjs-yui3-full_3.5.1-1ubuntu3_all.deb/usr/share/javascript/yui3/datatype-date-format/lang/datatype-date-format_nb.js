/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatype-date-format_nb",function(a){a.Intl.add("datatype-date-format","nb",{"a":["søn.","man.","tir.","ons.","tor.","fre.","lør."],"A":["søndag","mandag","tirsdag","onsdag","torsdag","fredag","lørdag"],"b":["jan.","feb.","mars","apr.","mai","juni","juli","aug.","sep.","okt.","nov.","des."],"B":["januar","februar","mars","april","mai","juni","juli","august","september","oktober","november","desember"],"c":"%a %d. %b %Y kl. %H.%M.%S %Z","p":["AM","PM"],"P":["am","pm"],"x":"%d.%m.%y","X":"kl. %H.%M.%S"});},"3.5.1");