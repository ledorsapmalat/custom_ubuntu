/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/datatable-message",function(a){a.Intl.add("datatable-message","",{emptyMessage:"No data to display",loadingMessage:"Loading..."});},"3.5.1");