/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/dial_es",function(a){a.Intl.add("dial","es",{label:"Mi etiqueta",resetStr:"Resetear",tooltipHandle:"Arrastre para ajustar el valor"});},"3.5.1");