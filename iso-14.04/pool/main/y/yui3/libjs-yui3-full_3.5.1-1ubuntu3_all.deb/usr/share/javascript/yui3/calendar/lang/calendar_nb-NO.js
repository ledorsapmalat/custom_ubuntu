/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar_nb-NO",function(a){a.Intl.add("calendar","nb-NO",{weekdays:["Søndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag"],very_short_weekdays:["Sø","Ma","Ti","On","To","Fr","Lø"],first_weekday:1,weekends:[0,6]});},"3.5.1");