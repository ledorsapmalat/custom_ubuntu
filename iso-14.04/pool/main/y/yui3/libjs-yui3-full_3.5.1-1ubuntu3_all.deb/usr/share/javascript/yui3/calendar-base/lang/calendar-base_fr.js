/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add("lang/calendar-base_fr",function(a){a.Intl.add("calendar-base","fr",{weekdays:["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"],short_weekdays:["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"],very_short_weekdays:["Di","Lu","Ma","Me","Je","Ve","Sa"],first_weekday:1,weekends:[0,6]});},"3.5.1");