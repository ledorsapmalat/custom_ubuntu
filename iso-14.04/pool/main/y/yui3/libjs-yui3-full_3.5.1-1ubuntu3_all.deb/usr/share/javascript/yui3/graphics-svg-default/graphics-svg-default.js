/*
YUI 3.5.1 (build 22)
Copyright 2012 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/
YUI.add('graphics-svg-default', function(Y) {

Y.Graphic = Y.SVGGraphic;
Y.Shape = Y.SVGShape;
Y.Circle = Y.SVGCircle;
Y.Rect = Y.SVGRect;
Y.Ellipse = Y.SVGEllipse;
Y.Path = Y.SVGPath;
Y.Drawing = Y.SVGDrawing;


}, '3.5.1' ,{skinnable:false});
