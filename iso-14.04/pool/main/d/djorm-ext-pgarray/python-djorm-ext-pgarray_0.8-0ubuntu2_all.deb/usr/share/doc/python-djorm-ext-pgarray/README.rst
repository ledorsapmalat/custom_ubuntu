djorm-ext-pgarray
=================

PostgreSQL native array fields extension for Django.
