/*
 * elf.h
 */

#ifndef _ELF_H
#define _ELF_H

#include <sys/elf32.h>
#include <sys/elf64.h>

#endif /* _ELF_H */
