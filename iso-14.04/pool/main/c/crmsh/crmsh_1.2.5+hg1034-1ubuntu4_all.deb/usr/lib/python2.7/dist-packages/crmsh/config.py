# Copyright (C) 2008-2011 Dejan Muhamedagic <dmuhamedagic@suse.de>
# Copyright (C) 2013 Kristoffer Gronlund <kgronlund@suse.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#

DATADIR = "/usr/share"
PACKAGE = "crmsh"
CRM_CACHE_DIR = "/var/cache/crm"
CRM_DTD_DIRECTORY = "/usr/share/pacemaker"
PE_STATE_DIR = "/var/lib/pacemaker/pengine"
CRM_CONFIG_DIR = "/var/lib/pacemaker/cib"
CRM_DAEMON_DIR = "/usr/lib/pacemaker"
CRM_DAEMON_USER = "hacluster"
VERSION = "1.2.5"
BUILD_VERSION = "f2f315daf6a5fd7ddea8e564cd289aa04218427d"
HA_VARLIBHBDIR = "/var/lib/heartbeat"
OCF_ROOT_DIR = "/usr/lib/ocf"

