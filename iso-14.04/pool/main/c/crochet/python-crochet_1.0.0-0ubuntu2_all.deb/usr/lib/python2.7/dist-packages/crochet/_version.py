"""
Store version in its own module so we can access it from both setup.py and
__init__.
"""
__version__ = "1.0.0"
